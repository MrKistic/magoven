<h3>New <?php echo sfInflector::humanize($this->getModuleName()) ?></h3>

[?php include_partial('form', array('form' => $form)) ?]
